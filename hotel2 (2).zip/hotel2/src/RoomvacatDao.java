import java.sql.*;
public class RoomvacatDao {
    public static int delete(int roomno){
        int status=0;
        try{
            Connection con=DB.getConnection();
            PreparedStatement ps=con.prepareStatement("delete from issueroom where roomno=?");
            ps.setInt(1,roomno);
            status=ps.executeUpdate();
            con.close();
        }catch(Exception e){System.out.println(e);}
        return status;
    }
}