import java.sql.Connection;
import java.sql.PreparedStatement;

public class EmployeeDao {
    public static int save(String employeeno,String name,String city,String Designation,String contact){
        int status=0;
        try{
            Connection con=DB.getConnection();
            PreparedStatement ps=con.prepareStatement("insert into Employee(employeeno,name,city,Designation,contact) values(?,?,?,?,?)");
            ps.setString(1,employeeno);
            ps.setString(2,name);
            ps.setString(3,city);
            ps.setString(4,Designation);
            ps.setString(5,contact);
            status=ps.executeUpdate();
            con.close();
        }catch(Exception e){System.out.println(e);}
        return status;
    }
}

