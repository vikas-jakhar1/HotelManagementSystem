import java.sql.Connection;
import java.sql.PreparedStatement;

public class IssueRoomDao {
    public static int save(String roomno,String customerid,String customername,String customercontact){
        int status=0;
        try{
            Connection con=DB.getConnection();
            PreparedStatement ps=con.prepareStatement("insert into issueroom(roomno,customerid,customername,customercontact) values(?,?,?,?)");
            ps.setString(1,roomno);
            ps.setString(2,customerid);
            ps.setString(3,customername);
            ps.setString(4,customercontact);
            status=ps.executeUpdate();
            con.close();
        }catch(Exception e){System.out.println(e);}
        return status;
    }
}

